﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
public class Player : MonoBehaviour
{
    public static Player Instance;

    void Awake()
    {
        if (Instance == null)
            Instance = this;
    }
    [SerializeField] CircleCollider2D redBallCollider;
    [SerializeField] CircleCollider2D blueBallCollider;
    [SerializeField] float speed;
    [SerializeField] float rotationSpeed;

    Rigidbody2D rb;
    Vector3 startPosition;
    // Start is called before the first frame update
    void Start()
    {
        startPosition = transform.position;
        rb = GetComponent<Rigidbody2D>();
        MoveUp();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            RotateLeft();
        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            RotateRight();
        }
        if (Input.GetKeyUp(KeyCode.LeftArrow) || Input.GetKeyUp(KeyCode.RightArrow))
            rb.angularVelocity = 0f;
    }
    void MoveUp()
    {
        rb.velocity = Vector2.up * speed;
    }
    void RotateLeft()
    {
        rb.angularVelocity = rotationSpeed;
    }
    void RotateRight()
    {
        rb.angularVelocity = rotationSpeed;
    }
    public void Restart()
    {
        redBallCollider.enabled = false;
        blueBallCollider.enabled = false;
        rb.angularVelocity = 0f;
        rb.velocity = Vector2.zero;

        transform
            .DORotate(Vector3.zero, 1f)
            .SetDelay(1f)
            .SetEase(Ease.InOutBack);
        transform
            .DOMove(startPosition, 1f)
            .SetDelay(1f)
            .SetEase(Ease.OutFlash);
            {
                redBallCollider.enabled = true;
                blueBallCollider.enabled = true;
                GameManaged.Instance.isGameover = false;
                MoveUp();
            };
    }
}
