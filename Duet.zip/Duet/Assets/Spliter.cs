﻿using UnityEngine;

public class Spliter : MonoBehaviour
{
    [SerializeField] Color[] colors = new Color[2];
    [SerializeField] GameObject splaterPrefact;
    [SerializeField] Sprite[] splatterSprites;
    // Start is called before the first frame update
    public void AddSplatter(Transform obstacle, Vector3 pos, int colorIndex)
    {
        GameObject splatter = Instantiate(splaterPrefact, pos, Quaternion.Euler(new Vector3(0f, 0f, Random.Range(-320f, 320f))), obstacle);

        SpriteRenderer sr = splatter.GetComponent<SpriteRenderer>();
        sr.color = colors[colorIndex];
        sr.sprite = splatterSprites[Random.Range(0, splatterSprites.Length)];
    }
 
}
