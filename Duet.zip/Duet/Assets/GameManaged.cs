﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManaged : MonoBehaviour
{
    public static GameManaged Instance;

    void Awake()
    {
        if (Instance == null)
            Instance = this;
    }

    [HideInInspector] public bool isGameover = false;
}
