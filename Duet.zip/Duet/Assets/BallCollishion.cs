﻿using UnityEngine;

public class BallCollishion : MonoBehaviour
{
    ParticleSystem explosionFx;
    int ballIndex;

    void Start()
    {
        explosionFx = transform.GetChild(0).GetComponent<ParticleSystem>();
        ballIndex = transform.position.x > 0 ? 0 : 1;
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.collider.CompareTag("Obstacle"))
        {
            GameManaged.Instance.isGameover = true;
            explosionFx.Play();
            Spliter.Instance.AddSplatter(other.transform, other.contacts[0].point, ballIndex);
            Player.Instance.Restart();
        }
    }
}
